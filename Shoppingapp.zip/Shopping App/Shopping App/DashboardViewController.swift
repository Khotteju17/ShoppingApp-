//
//  DashboardViewController.swift
//  Shopping App
//
//  Created by Tejashree on 20/05/23.
//

import Foundation
import UIKit
import Kingfisher

class DashboardViewController : UIViewController{
    static var identifier = "DashboardViewController"
    
    @IBOutlet weak var tableview : UITableView!
    
    private var webService: WebService!
    private var productListViewModel: ProductDataListViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
        webService = WebService()
        productListViewModel = ProductDataListViewModel(webService: webService, completion: {
            if !self.productListViewModel.productDataListViewModel.isEmpty{
                self.tableview.reloadData()
            }
        })
    }
}
// MARK: - UITableViewDelegate, UITableViewDataSource
extension DashboardViewController : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productListViewModel.productDataListViewModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: DashboardTableViewCell.reuseidentifier, for: indexPath) as! DashboardTableViewCell
        
        let product = productListViewModel.productAt(index: indexPath.row)
        cell.titleLabel.text = product.title
        cell.priceLabel.text = String(product.price)
        cell.brandLabel.text = product.brand
        
        let resource = ImageResource(downloadURL: URL(string: product.thumbnail)!, cacheKey: product.thumbnail)
        cell.productImage.kf.setImage(with: resource)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let loginStoryBoard:UIStoryboard! = UIStoryboard(name: "Main", bundle: nil)
        let nvc = loginStoryBoard.instantiateViewController(withIdentifier: DetailsViewController.identifier) as! DetailsViewController
        nvc.modalPresentationStyle = .fullScreen
        nvc.selectedProduct = productListViewModel.productAt(index: indexPath.row)
        self.present(nvc, animated: true, completion: nil)
    }
    
}

// MARK: - UITableViewDataSourcePrefetching
extension DashboardViewController: UITableViewDataSourcePrefetching {
    
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
        self.productListViewModel.populateproducts()
    }
}

class DashboardTableViewCell: UITableViewCell {
    static let reuseidentifier = "DashboardTableViewCell"
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var brandLabel: UILabel!
    @IBOutlet var productImage: UIImageView!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
}
