//
//  LoginViewController.swift
//  Shopping App
//
//  Created by Tejashree on 20/05/23.
//

import Foundation
import UIKit
import AuthenticationServices
import FBSDKCoreKit
import FBSDKLoginKit
import GoogleSignIn

class LoginViewController: UIViewController {
    static var identifier = "LoginViewController"
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var facebookButton: UIButton!
    @IBOutlet weak var googleButton: UIButton!
    @IBOutlet weak var appleButton: UIButton!
    let viewModel = LoginViewModel()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        initializeData()
    }
    
    private func initializeData() {
        /// Placeholder text
        userNameTextField.placeholder = "Username"
        passwordTextField.placeholder = "Password"
        
        signInButton.corner()
        [facebookButton, googleButton, appleButton].forEach { $0?.corner(radius: 10) }
        
        /// Delegate the protocol
        viewModel.delegate = self
    }
    
    // MARK: - IBAction
    @IBAction func didTapSignInButton(_ sender: Any) {
        //    viewModel.login(username: userNameTextField.text, password: passwordTextField.text, type: .normal)
        if !userNameTextField.text!.isEmpty && !passwordTextField.text!.isEmpty{
            let loginStoryBoard:UIStoryboard! = UIStoryboard(name: "Main", bundle: nil)
            let nvc = loginStoryBoard.instantiateViewController(withIdentifier: DashboardViewController.identifier) as! DashboardViewController
            nvc.modalPresentationStyle = .fullScreen
            self.present(nvc, animated: true, completion: nil)
        }else{
            showPopup(isSuccess: false, type: .normal )
            return
        }
        
    }
    
    @IBAction func didTapFacebookButton(_ sender: Any) {
        handleFacebookAuthentication()
    }
    
    @IBAction func didTapGoogleButton(_ sender: Any) {
        handleGoogleAuthentication()
    }
    
    @IBAction func didTapAppleButton(_ sender: Any) {
        handleAppleAuthentication()
    }
}

// MARK: - Login with Apple
extension LoginViewController: ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
    
    /// Our custom functions
    private func handleAppleAuthentication() {
        let appleIDProvider = ASAuthorizationAppleIDProvider()
        let request = appleIDProvider.createRequest()
        request.requestedScopes = [.fullName, .email]
        
        let authorizationController = ASAuthorizationController(authorizationRequests: [request])
        authorizationController.presentationContextProvider = self
        authorizationController.delegate = self
        authorizationController.performRequests()
    }
    
    /// Required functions from protocols
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        guard let appleCredential = authorization.credential as? ASAuthorizationAppleIDCredential else { return }
        viewModel.login(username: appleCredential.email, password: nil, type: .apple)
        viewModel.token = String(describing: appleCredential.identityToken.hashValue)
    }
    
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        return self.view.window!
    }
}

// MARK: - Login with facebook
extension LoginViewController {
    
    /// Our custom functions
    private func handleFacebookAuthentication() {
        let loginManager = LoginManager()
        loginManager.logIn(permissions: ["email"], from: self) { (result, error) in
            if error != nil {
                self.showPopup(isSuccess: false, type: .facebook)
                return
            }
            guard let token = AccessToken.current else {
                print("Failed to get access token")
                self.showPopup(isSuccess: false, type: .facebook)
                return
            }
            self.viewModel.token = token.appID
            
            GraphRequest(graphPath: "me", parameters: ["fields": "email"]).start(completionHandler: { (connection, result, error) -> Void in
                if (error == nil), let result = result as? [String: Any], let email = result["email"] as? String {
                    self.viewModel.login(username: email, password: "", type: .facebook)
                }
            })
        }
    }
}

// MARK: - Login with google
extension LoginViewController {
    
    /// Our custom functions
    private func handleGoogleAuthentication() {
        let configuration = GIDConfiguration(clientID: "350995020018-79bumcion7icu71tvev6qie3nos6bul3.apps.googleusercontent.com")
        
        //      GIDSignIn.sharedInstance.signIn(with: configuration, presenting: self) { [unowned self] user, error in
        //          if error != nil {
        //              showPopup(isSuccess: false, type: .google)
        //          } else if let user = user {
        //              viewModel.login(username: user.profile?.name ?? "no name", password: "", type: .google)
        //          } else {
        //              showPopup(isSuccess: false, type: .google)
        //          }
        //      }
    }
    
    /// Required functions from protocols
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        
    }
}

// MARK: - Show result
extension LoginViewController: LoginResultProtocol {
    
    func showPopup(isSuccess: Bool, user: User? = nil, type: LoginType) {
        let successMessage = "Congratulation! \(user?.username ?? ""). You logged in successully with \(type.name). "
        let errorMessage = "Please enter the correct details. Please try again"
        let alert = UIAlertController(title: isSuccess ? "Success": "Error", message: isSuccess ? successMessage: errorMessage, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Done", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func success(user: User?, type: LoginType) {
        //    showPopup(isSuccess: true, user: viewModel.user, type: type)
        
        let loginStoryBoard:UIStoryboard! = UIStoryboard(name: "Main", bundle: nil)
        let nvc = loginStoryBoard.instantiateViewController(withIdentifier: DashboardViewController.identifier) as! DashboardViewController
        nvc.modalPresentationStyle = .fullScreen
        self.navigationController?.present(nvc, animated: true, completion: nil)
    }
    
    func error(error: Error, type: LoginType) {
        showPopup(isSuccess: false, type: type)
    }
}

protocol LoginFunctionProtocol {
  
  func login(username: String?, password: String?, type: LoginType)
}

protocol LoginResultProtocol: class {
  func success(user: User?, type: LoginType)
  func error(error: Error, type: LoginType)
}

class LoginViewModel: LoginFunctionProtocol {
    
    var user: User?
    var token: String?
    weak var delegate: LoginResultProtocol?
    
    func login(username: String?, password: String?, type: LoginType) {
        /// It should have other validations here, if error, we will return error
        if let username = username, let password = password {
            user = User(username: username, password: password, token: token)
            delegate?.success(user: user, type: type)
        } else {
            delegate?.error(error: NSError(domain: "Value is nil", code: 1, userInfo:nil), type: type)
        }
    }
}

protocol LoginService {
    func login(username: String, password: String, success: @escaping (User, String) -> Void, failure: @escaping (Error?) -> Void)
}
enum LoginType: String {
    case normal = "Sign In normally"
    case facebook = "Facebook"
    case apple = "Apple"
    case google = "Google"
    
    var name: String {
        return self.rawValue
    }
}

struct User {
    var username: String?
    var password: String?
    var token: String?
    
    init(username: String?, password: String?, token: String? = nil) {
        self.username = username
        self.password = password
        self.token = token
    }
}
extension UIView {
    func corner(radius: CGFloat = 25) {
        self.layer.cornerRadius = radius
        self.layer.masksToBounds = true
    }
}
