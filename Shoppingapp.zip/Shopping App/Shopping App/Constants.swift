//
//  Constants.swift
//  Shopping App
//
//  Created by Tejashree on 21/05/23.
//

import Foundation
enum Constants: String {

    case SHOPPING_BASE_URL = "https://dummyjson.com/products"
}

var MAX_PAGE = 1
